# MENTE RÁPIDA — Ábaco Japonés (Android)

Este proyecto empaqueta el juego HTML local en una aplicación Android (WebView), con icono institucional y modo de pantalla completa. El HTML se incluye en `app/src/main/assets/index.html` para poder abrir el juego sin conexión.

## Obtener el APK sin instalar Android Studio en tu computadora

Se incluyó una acción automática que compila el APK en GitHub Actions.

1. Entra a https://github.com/ y crea una cuenta gratuita si aún no tienes una.
2. Crea un repositorio nuevo llamado `MenteRapidaAndroid`.
3. Sube el contenido de esta carpeta al repositorio (no subas la carpeta ZIP como un solo archivo; descomprime y sube los archivos y carpetas).
4. En el repositorio, abre **Actions** y selecciona **Compilar APK de Mente Rapida**.
5. Pulsa **Run workflow** y espera que termine con una marca verde.
6. En esa ejecución, baja hasta **Artifacts** y descarga `Mente-Rapida-APK.zip`. Dentro estará `app-debug.apk`.
7. Envía `app-debug.apk` a tu teléfono Android y ábrelo para instalarlo. Android puede pedirte autorizar temporalmente la instalación desde esa fuente.

## Datos
- Nombre: Mente Rápida — Ábaco Japonés
- Identificador: `pe.mente.rapida`
- Orientación: horizontal
- Juego HTML e imágenes: incluidos localmente
- La compilación automática genera un APK de prueba (`debug`), no uno firmado para publicar en Google Play.
